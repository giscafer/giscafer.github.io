/**
 * 通用方法
 */
define(function(require,exports,module) {
    /**
     * 播放声音
     * @param sound 声音文件路径
     */
    exports.soundPlay = function(sound) {
        if (navigator.appName == "Microsoft Internet Explorer") { //IE浏览器
            var snd = document.createElement("bgsound");
            document.getElementsByTagName("body")[0].appendChild(snd);
            snd.id = "event_sound_id";
            //最大音量
            snd.volume = 0;
            //无限次循环
            //        snd.loop=-1;
            snd.src = sound;
        } else {
            var obj = document.createElement("object");
            obj.id = "event_sound_id";
            obj.width = "0px";
            obj.height = "0px";
            obj.type = "audio/x-wav";
            obj.data = sound;
            var body = document.getElementsByTagName("body")[0];
            body.appendChild(obj);
            /*         var audio = document.createElement("audio");
                     //无限次播放
                     audio.loop="loop";
                     audio.id="event_sound_id";
                     audio.src=sound;
                     audio.autoplay="autoplay";
                     $('body').append(audio);*/
        }

    };
    /**
     * 更新后台缓存Session信息
     * @param {Object} strAttr 属性对象
     * @param {Object} strVal 属性值
     * @param {Object} func 属性更新成功回调函数
     */
    exports.updateSession = function(strAttr, strVal, func) {
        var code = "sessionAttr=" + strAttr + "&sessionValue=" + strVal;
        $.ajax({
            type: "POST",
            url: "updateSessionInfo.do",
            data: code,
            success: func
        });
    };
    /**
     * 弹窗窗口接口
     * @param  {String} htmlUrl   窗体Url
     * @param  {String} title     标题
     * @param  {String} tableName  表名
     * @param  {String} data      数据
     * @param  {String} formId    窗口ID
     */
    function showDetailPanel(htmlUrl, title, tableName, data, formId) {
        mini.openIbox({
            url: htmlUrl,
            requestType: "ajax",
            title: title,
            onload: function() {
                window.openIboxView = this;
                if (data != null) {
                    if (formId) {
                        var form = new mini.FsForm({
                            formId: formId,
                            tableName: tableName,
                            data: data,
                            isFlow: true
                        });
                    } else {
                        setData(data);
                    }
                }
                $(".mini-fs-close-button").show();
                $(".mini-fs-save-button").hide();
                $(".mini-fs-close-button").click(function() {
                    window.openIboxView.close();
                });
            },
            ondestroy: function() {
                window.openIboxView = null;
            }
        });
    }
    /**
     * grid双击行弹窗
     */
    exports.gridRowDbClickFunc = function(e) {
        var sender = e.sender;
        var data = e.record;
        showDetailPanel(sender.popFormUrl, sender.moduleName, sender.tableName, data, sender.popFormId);
    }

    /**
     * 通知公告双击弹窗
     */
    exports.tzggRowDbclickFunc = function(e) {
        var sender = e.sender;
        var data = e.record;
        mini.openIbox({
            url: '../home?template=WEB-INF/view/module/tzgg/tzgg_info.html',
            requestType: 'ajax',
            title: '公告详情',
            onload: function() {
                var box = this;
                var tzggForm = new mini.FsForm({
                    formId: "popForm-tzgg-info-datagrid",
                    tableName: "XH_TZGG_TB_V",
                    data: data,
                    isFlow: true
                });
                tzggInfoPopForm = this;
                $("#winCl").click(function() {
                    tzggInfoPopForm.close();
                });
            }
        });
    }

    /**
     * 获得当前登录系统用户名称
     * @return {[type]} [description]
     */
    exports.getCurrentUserName = function() {
            var userRealName = null;
            if (Forestar.App.loginUser != null)
                userRealName = Forestar.App.loginUser.userRealName;
            return userRealName;
        }
    /**
     * 检测是否手机号 
     * @param  {String}  sMobile 手机号字符串
     * @return {Boolean}  true则为正确手机格式
     */
    exports.isPhoneNumber = function(sMobile) {

            if (/^1[3|4|5|6|7|8][0-9]\d{4,8}$/.test(sMobile)) {
                return true;
            } else {
                return false;

            }
        }
    /**
     * datagrid自适应函数,尚未封装成类，仅是一种临时的解决方案
     * @param {[type]} gridId gridId表示表格的ID,dx:高度偏差
     * @param {[type]} dx     高度偏差
     */
    exports.setGridHeightAuto = function(gridId, dx) {
            //获取head logo的高度
            var headHeight = $(".zs-top").height();
            //获取一级菜单高度，注意：一级菜单有时候和log栏在重叠在一起，不用额外计算菜单栏高度
            var menuHeight = $(".zs-top").height();
            var locationHeight = $(".zs-location").height();
            //50表示grid表格toolbar栏的高度
            var winHeight = $(window).height() - headHeight - locationHeight - 70;
            if (dx) {
                winHeight = winHeight + dx;
            }
            $("#" + gridId).css({
                height: winHeight
            });
            window.onresize = function() {
                var locationHeight = $(".zs-location").height();
                var winHeight = $(window).height() - $(".fore-2d3d-head").height() - $(".fore-2d3d-menu").height() + 30 - locationHeight;
                if (dx) {
                    winHeight = winHeight + dx;
                }
                $("#" + gridId).css({
                    height: winHeight
                });
            }
        }
    /**
     * 设置监控导航树的自适应高度
     */
    exports.setJkdhTreeHeightAuto = function(id, dx) {
        //获取head logo的高度
        var headHeight = $("#fore-2d3d-head").height();
        //获取一级菜单高度，注意：一级菜单有时候和log栏在重叠在一起，不用额外计算菜单栏高度
        var menuHeight = $(".fore-2d3d-menu").height();
        //地图工具栏的高度
        var ToolHeight = $(".fore-core-location").height();
        //titleH表示ibox-title栏的高度
        var titleH = $(".fore-core-ibox-title").height();
        //itab-title
        var itabH = $(".fore-core-itab-title").height();
        //button
        var btnH = $(".fore-common-btn").height();
        //
        var treeHeight = $(window).height() - headHeight - menuHeight - ToolHeight - titleH - itabH - btnH;
        if (dx) {
            if (typeof dx == "number")
                treeHeight += dx;
        }
        $("#" + id).css({
            height: treeHeight
        });
        window.onresize = function() {
            var headHeight = $("#fore-2d3d-head").height();
            var menuHeight = $(".fore-2d3d-menu").height();
            var ToolHeight = $(".fore-core-location").height();
            var titleH = $(".fore-core-ibox-title").height();
            var itabH = $(".fore-core-itab-title").height();
            var btnH = $(".fore-common-btn").height();
            var treeHeight = $(window).height() - headHeight - menuHeight - ToolHeight - titleH - itabH - btnH;
            if (dx) {
                if (typeof dx == "number")
                    treeHeight += dx;
            }
            $("#" + id).css({
                height: treeHeight
            });
        };
    }

    /**
     * 以下是模拟ForEach方法（因为IE8不支持，而本人喜欢用forEach,so网上搜了一下）
     * @param object
     * @param block
     * @param context
     * @param fn
     */

    exports.forEach = function(object, block, context, fn) {
        if (object == null) return;
        if (!fn) {
            if (typeof object == "function" && object.call) {
                //遍历普通对象
                fn = Function;
            } else if (typeof object.forEach == "function" && object.forEach != arguments.callee) {
                //如果目标已经实现了forEach方法，则使用它自己的forEach方法（如标准游览器的Array对象）
                object.forEach(block, context);
                return;
            } else if (typeof object.length == "number") {
                // 如果是类数组对象或IE的数组对象
                _Array_forEach(object, block, context);
                return;
            }
        }
        _Function_forEach(fn || Object, object, block, context);
    }

    function _Array_forEach(array, block, context) {
        if (array == null) return;
        var i = 0,
            length = array.length;
        if (typeof array == "string") {
            for (; i < length; i++) {
                block.call(context, array.charAt(i), i, array);
            }
        } else {
            for (; i < length; i++) {
                block.call(context, array[i], i, array);
            }
        }
    }
    _Function_forEach = function(fn, object, block, context) {
        // 这里的fn恒为Function
        for (var key in object) {
            //只遍历本地属性
            if (object.hasOwnProperty(key)) {
                //相当于 block(object[key], key)
                block.call(context, object[key], key, object);
            }
        }
    };
    /**
     *判断一个对象数组中是否包含有该对象
     * @param Arr 对象数组
     * @param obj 对象
     * @returns {boolean}
     */
    exports.containsObj = function(Arr, obj) {
            var flag = false;
            $.each(Arr, function(index, item) {
                if (item.id === obj.id) {
                    flag = true;
                }
            });
            /* IE8不支持
            Arr.forEach(function(item){
                 if(item.id===obj.id){
                     flag=true;
                 }
             });*/
            return flag;
        }
    /**
     *移除一个对象数组中的该对象
     * @param Arr 对象数组
     * @param obj 对象
     * @returns {boolean}
     */
    exports.removeObj = function(Arr, obj) {
            $.each(Arr, function(index, item) {
                var condition = obj.channel ? (item.channel == obj.channel) : (1 == 1);
                if (item.id === obj.id && condition) {
                    Arr.splice(index, 1);
                }
            });
            /* IE8不支持
            Arr.forEach(function(item,index){
                 var condition=obj.channel?(item.channel==obj.channel):(1==1);
                 if(item.id===obj.id && condition){
                     Arr.splice(index,1);
                 }
             });*/
            return Arr;
        }
        /*
         * 加载图片
         * @param SJ_CODE 事件编号
         * */
    var pichtml = "";

    exports.loadPicFormDB = function(SJ_CODE, id) {
            if (id == "" || id == null) {
                id = "vtab_sjxx_pic";
            }
            pichtml = "";
            var wqf = {};
            wqf.selectFields = "*";
            wqf.whereString = " SJ_CODE IN (" + SJ_CODE + ")";
            ajaxDataService.getEntityList("XH_SHIJIAN_FJ_TB", wqf, function(result) {
                if (result.length > 0) {
                    var $vtabpic = $("#" + id);
                    var html = '<div id="gallery2" style=" white-space: nowrap">'
                    for (var i = 0; i < result.length; i++) {
                        var src = Config.hostUrl + result[i].originalObjects.FJ_LJ;
                        var thumb = Config.hostUrl + result[i].originalObjects.FJ_LJ_COMPRES;
                        if (i <= 4) {
                            html += '<a href="' + src + '" target="_blank" title="' + result[i].originalObjects.FJ_NAME +
                                '" style="display: inline-block;"><img onload="AutoResizeImage(80, 80, this)" src="' +
                                thumb + '"></a>&nbsp;&nbsp;';
                        } else {
                            html += '<a href="' + src + '" target="_blank" title="' + result[i].originalObjects.FJ_NAME +
                                '" style="display: none;"><img onload="AutoResizeImage(80,80,this)" src="' + thumb + '"></a>';
                        }
                    }
                    html += '</div>';
                    $vtabpic.append(html);

                } else {
                    var $vtabpic = $("#" + id);
                    var html = '<img style="width: 60px;height: 80px;" src=""/>';
                    $vtabpic.append(html);
                }
                $("#" + id).rebox({
                    selector: 'a'
                });
                //        scrollPic();
            });
        }
    /**
     * 按比例缩小图片
     * @param maxWidth
     * @param maxHeight
     * @param objImg
     * @constructor
     */
    function AutoResizeImage(maxWidth, maxHeight, objImg) {
        var img = new Image();
        img.src = objImg.src;
        var hRatio;
        var wRatio;
        var Ratio = 1;
        var w = img.width;
        var h = img.height;
        wRatio = maxWidth / w;
        hRatio = maxHeight / h;
        if (maxWidth == 0 && maxHeight == 0) {
            Ratio = 1;
        } else if (maxWidth == 0) { //
            if (hRatio < 1)
                Ratio = hRatio;
        } else if (maxHeight == 0) {
            if (wRatio < 1)
                Ratio = wRatio;
        } else if (wRatio < 1 || hRatio < 1) {
            Ratio = (wRatio <= hRatio ? wRatio : hRatio);
        }
        if (Ratio < 1) {
            w = w * Ratio;
            h = h * Ratio;
        }
        objImg.height = h;
        objImg.width = w;
    }
    /**
     * 分析统计测试
     * @param  {String} dateStr 日期字符串，如：2015-09-02
     */
    exports.fxtjHlyKQDay = function(dateStr) {
        var tjDate;
        //统计具体某一天
        if (dateStr) {
            tjDate = dateStr;
        } else {
            //获取昨天的日期
            tjDate = DateUtils.getFormatDay(DateUtils.getProxDay());
        }
        $.ajax({
            type: "POST",
            //此处使用的是自己封装的JAVA类
            url: Config.hostUrl + "/fxtjHlyKQDay.do",
            data: {
                params: tjDate
            },
            success: function(data) {
                console.log('统计fxtjHlyKQDay');
            },
            error: function(e) {
                console.log(e);
            }
        });
    };
    /**
     * 坐标转换
     * @param  {Number} x           经度
     * @param  {Number} y           纬度
     * @param  {String} sourceEPSG  原坐标参考
     * @param  {String} targetEPSG  目标坐标参考
     * @return {Object}  XY          
     */
    exports.transfromOpenLayers = function(x, y, sourceEPSG, targetEPSG) {
        var s_epsg = sourceEPSG + "";
        if (s_epsg.indexOf("EPSG") < 0) {
            s_epsg = "EPSG:" + s_epsg;
        }
        var t_epsg = targetEPSG + "";

        if (!t_epsg) {
            t_epsg = s_epsg;
        } else {
            if (t_epsg.indexOf("EPSG") < 0) {
                t_epsg = "EPSG:" + t_epsg;
            }
        }
        var targetProj = new OpenLayers.Projection(t_epsg);
        var currentProj = new OpenLayers.Projection(s_epsg);
        // 投影
        var XY = new OpenLayers.Geometry.Point(x, y);
        XY.transform(currentProj, targetProj);
        AppEvent.dispatchEvent("commonOlProject", XY);
        return XY;
    }

});
