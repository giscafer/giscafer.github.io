define(function(require, exports, module) {
    window.c = require('common/commonUtil');
    console.log('c', c);
});
